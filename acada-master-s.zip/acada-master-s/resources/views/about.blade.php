
<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
 

 @include('includes.head')

  <body>

    <div class="container">

     @include('includes.nav')

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron">
        <h1>ABOUT ACADA</h1>
        
          <a class="btn btn-lg btn-primary" href="../../components/#navbar" role="button">View navbar docs &raquo;</a>
        </p>
      </div>

    </div> <!-- /container -->



 @include('includes.footer')
  </body>
</html>
