<div class="col-sm-3 col-md-2 sidebar">
          <ul class="nav nav-sidebar">
          <!--  <li class="active"><a href="#">Overview <span class="sr-only">(current)</span></a></li> -->
            <li><a href="<?php echo e(url('home')); ?>">Dashboard</a></li>
            <li><a href="<?php echo e(url('allvideo')); ?>">All Video</a></li>
            <li><a href="<?php echo e(url('upload')); ?>">Upload Video</a></li>
          </ul>
         
          
        </div>